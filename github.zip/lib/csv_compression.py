import os
import time
from pathlib import Path
from sc_compression import compress, decompress
from sc_compression.signatures import Signatures

GREEN = '\033[92m'
YELLOW = '\033[93m'
RED = '\033[91m'
RESET = '\033[0m'

# 创建目录结构
def create_csv_folders():
    base_dir = Path("CSV")
    dirs = [
        "In-Compressed",      # 待解压的CSV.gz文件
        "In-Decompressed",    # 待压缩的CSV文件
        "Out-Compressed",     # 压缩后的输出目录
        "Out-Decompressed"    # 解压后的输出目录
    ]
    
    for dir_name in dirs:
        dir_path = base_dir / dir_name
        dir_path.mkdir(parents=True, exist_ok=True)
    
    return base_dir

# 检查目录状态
def check_directory_status(path, expected_files):
    if not path.exists():
        return False, f"目录不存在: {path}"
    
    files = list(path.glob(expected_files))
    if not files:
        return False, f"目录中没有找到匹配的文件: {path}"
    
    return True, files

# 解压CSV文件（使用sc_compression）
def decompress_csv():
    # 注意：已移除开始提示，由main.py负责显示
    start_time = time.time()
    
    base_dir = create_csv_folders()
    input_dir = base_dir / "In-Compressed"
    output_dir = base_dir / "Out-Decompressed"
    
    # 检查输入目录
    status, result = check_directory_status(input_dir, "*.csv")
    if not status:
        print(f"{YELLOW}{result}{RESET}")
        print(f"请将压缩的CSV文件放入: {input_dir}")
        return True
    
    compressed_files = result
    
    print(f"找到 {len(compressed_files)} 个压缩文件:")
    for file in compressed_files:
        print(f"  - {file.name}")
    
    # 解压文件
    success_count = 0
    for file in compressed_files:
        output_path = output_dir / file.name
        
        try:
            # 读取压缩文件
            with open(file, 'rb') as f:
                compressed_data = f.read()
            
            # 使用sc_compression解压
            decompressed_data = decompress(compressed_data)[0]
            
            # 写入解压后的文件
            with open(output_path, 'wb') as f:
                f.write(decompressed_data)
            
            print(f"解压完成: {file.name} -> {output_path.name}")
            success_count += 1
        except Exception as e:
            print(f"{RED}解压失败 {file.name}: {str(e)}{RESET}")
    
    # 计算并显示耗时（使用绿色）
    elapsed_time = time.time() - start_time
    print(f"{GREEN}成功解压 {success_count}/{len(compressed_files)} 个文件到: {output_dir}")
    print(f"{GREEN}操作耗时: {elapsed_time:.2f} 秒{RESET}")
    return True

# 压缩CSV文件（使用sc_compression）
def compress_csv():
    # 注意：已移除开始提示，由main.py负责显示
    start_time = time.time()
    
    base_dir = create_csv_folders()
    input_dir = base_dir / "In-Decompressed"
    output_dir = base_dir / "Out-Compressed"
    
    # 检查输入目录
    status, result = check_directory_status(input_dir, "*.csv")
    if not status:
        print(f"{YELLOW}{result}{RESET}")
        print(f"请将CSV文件放入: {input_dir}")
        return True
    
    csv_files = result
    
    print(f"找到 {len(csv_files)} 个CSV文件:")
    for file in csv_files:
        print(f"  - {file.name}")
    
    # 压缩文件
    success_count = 0
    for file in csv_files:
        output_path = output_dir / file.name
        
        try:
            # 读取CSV文件
            with open(file, 'rb') as f:
                csv_data = f.read()
            
            # 使用sc_compression压缩（使用LZMA算法）
            compressed_data = compress(csv_data, Signatures.LZMA)
            
            # 写入压缩文件
            with open(output_path, 'wb') as f:
                f.write(compressed_data)
            
            print(f"压缩完成: {file.name} -> {output_path.name}")
            success_count += 1
        except Exception as e:
            print(f"{RED}压缩失败 {file.name}: {str(e)}{RESET}")
    
    # 计算并显示耗时（使用绿色）
    elapsed_time = time.time() - start_time
    print(f"{GREEN}成功压缩 {success_count}/{len(csv_files)} 个文件到: {output_dir}")
    print(f"{GREEN}操作耗时: {elapsed_time:.2f} 秒{RESET}")
    return True
