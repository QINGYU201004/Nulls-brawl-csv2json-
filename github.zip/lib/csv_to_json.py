import csv
import json
import os
import time
import glob
from collections import defaultdict
from tqdm import tqdm

def load_config(config_file="config.json"):
    """从JSON文件加载配置"""
    if not os.path.exists(config_file):
        print(f"错误: 配置文件 {config_file} 不存在")
        return None
    
    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
            print(f"已加载配置文件: {config_file}")
            return config
    except Exception as e:
        print(f"加载配置文件出错: {str(e)}")
        return None

def clean_csv_value(value):
    """清理CSV值，精确处理空值情况"""
    if value is None:
        return None
    
    if not isinstance(value, str):
        return value
    
    # 去除首尾空白
    value = value.strip()
    
    # 处理明确的空值表示
    if not value or value in ['""', '""""', 'null', 'NULL', 'Null']:
        return None
    
    # 处理带引号的空字符串
    if value == '""' or value == '""""':
        return None
    
    # 简单去除首尾双引号（保留内容中的双引号）
    if value.startswith('"') and value.endswith('"'):
        value = value[1:-1]
    
    # 处理连续双引号转义
    value = value.replace('""', '"')
    
    # 再次检查是否为空
    if not value:
        return None
    
    return value

def convert_value(value, data_type):
    """根据数据类型转换值，保留null值"""
    # 如果值为None，直接返回None
    if value is None:
        return None
    
    try:
        if data_type == 'int':
            return int(value) if value is not None else None
        elif data_type == 'float':
            return float(value) if value is not None else None
        elif data_type == 'bool':
            # 布尔类型转换
            if value is None:
                return None
            if isinstance(value, str):
                if value.lower() in ['true', 'yes', '1']:
                    return True
                elif value.lower() in ['false', 'no', '0']:
                    return False
                else:
                    # 无法识别的布尔值，返回原值
                    return value
            elif isinstance(value, (int, float)):
                return bool(value)
            else:
                return value
        else:  # string或其他类型
            return value  # 直接返回原值
    except (ValueError, AttributeError):
        # 转换失败时返回原值
        return value

def find_matching_files(config):
    """根据配置查找匹配的文件对"""
    base_path = config.get("data_folder", ".")
    pattern = config.get("csv_pattern", "* (1).csv")
    
    # 查找所有修改版文件
    modified_files = glob.glob(os.path.join(base_path, pattern))
    
    pairs = []
    
    for modified_file in modified_files:
        # 获取文件名
        filename = os.path.basename(modified_file)
        
        # 从配置的模式中提取通配符部分
        pattern_parts = pattern.split("*")
        if len(pattern_parts) != 2:
            print(f"警告: 无效的文件模式 {pattern}，应包含单个 '*' 通配符")
            continue
            
        prefix, suffix = pattern_parts
        
        # 检查文件名是否匹配模式
        if filename.startswith(prefix) and filename.endswith(suffix):
            # 提取原版文件名部分
            original_suffix = suffix.replace(" (1)", "")  # 移除修改版标识
            original_name = filename[len(prefix):-len(suffix)] + original_suffix
            
            original_file = os.path.join(base_path, original_name)
            
            # 检查原版文件是否存在
            if os.path.exists(original_file):
                # 确定JSON键名 (使用原始文件名)
                json_key = os.path.splitext(original_name)[0]
                pairs.append((original_file, modified_file, json_key))
            else:
                print(f"警告: 未找到原版文件 {original_file}")
        else:
            # 处理根目录文件
            if pattern == "* (1).csv" and filename.endswith(" (1).csv"):
                # 尝试匹配根目录文件
                original_name = filename.replace(" (1).csv", ".csv")
                original_file = os.path.join(base_path, original_name)
                
                if os.path.exists(original_file):
                    json_key = os.path.splitext(original_name)[0]
                    pairs.append((original_file, modified_file, json_key))
                else:
                    print(f"警告: 未找到原版文件 {original_file}")
            else:
                print(f"警告: 忽略不匹配的文件 {filename}")
    
    return pairs

def get_key_field(header, key_fields):
    """根据配置的关键字段列表，在表头中查找存在的字段"""
    for field in key_fields:
        if field in header:
            return field
    return None  # 如果没有找到任何关键字段

def extract_nested_values(file_path, key_fields):
    """从CSV文件中提取嵌套值结构，正确处理空值并避免无意义字段"""
    result = {}
    current_key = None
    current_nested = defaultdict(list)
    
    print(f"  开始提取CSV文件: {os.path.basename(file_path)}")
    start_time = time.time()
    
    try:
        # 获取文件大小
        file_size = os.path.getsize(file_path)
        print(f"  文件大小: {file_size/(1024*1024):.2f} MB")
        
        # 统计行数
        with open(file_path, 'r', encoding='utf-8') as f:
            # 跳过标题行和类型行
            next(f)  # 标题行
            next(f)  # 类型行
            line_count = sum(1 for _ in f)
        
        print(f"  总行数: {line_count}")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            # 读取标题行
            header_line = next(f)
            header = [col.strip('"') for col in next(csv.reader([header_line]))]
            
            # 确定使用的关键字段
            key_field = get_key_field(header, key_fields)
            if not key_field:
                print(f"  错误: 在表头中未找到任何关键字段: {key_fields}")
                return {}
            
            print(f"  使用关键字段: {key_field}")
            
            # 读取类型行
            type_line = next(f)
            type_list = [t.strip() for t in next(csv.reader([type_line]))]
            
            # 创建字段类型映射
            field_types = dict(zip(header, type_list))
            
            # 使用tqdm显示实时进度条
            reader = csv.DictReader(f, fieldnames=header)
            pbar = tqdm(total=line_count, desc="提取进度", unit="行")
            
            for row in reader:
                # 清理字段值 - 保留空值为None
                cleaned_row = {}
                for k, v in row.items():
                    cleaned_value = clean_csv_value(v)
                    # 获取字段类型并转换值
                    data_type = field_types.get(k, 'string')
                    converted_value = convert_value(cleaned_value, data_type)
                    cleaned_row[k] = converted_value
                
                # 检查关键字段是否存在且不为空
                if key_field in cleaned_row and cleaned_row[key_field] is not None:
                    # 保存当前嵌套结构 - 首先过滤掉空值字段
                    if current_key and current_nested:
                        # 过滤掉所有值为空列表的字段
                        keys_to_remove = [k for k, v in current_nested.items() if not v]
                        for k in keys_to_remove:
                            del current_nested[k]
                            
                        if current_nested:  # 只保存有实际内容的嵌套结构
                            result[current_key] = dict(current_nested)
                    
                    # 开始新嵌套结构
                    current_key = cleaned_row[key_field]
                    current_nested = defaultdict(list)
                    
                    # 添加当前行数据到嵌套结构
                    for field, value in cleaned_row.items():
                        if field != key_field and value is not None:
                            current_nested[field].append(value)
                else:
                    # 添加值到当前嵌套结构
                    for field, value in cleaned_row.items():
                        if value is not None:
                            current_nested[field].append(value)
                
                pbar.update(1)  # 更新进度条
            
            # 保存最后一个嵌套结构 - 同样过滤掉空值字段
            if current_key and current_nested:
                # 过滤掉所有值为空列表的字段
                keys_to_remove = [k for k, v in current_nested.items() if not v]
                for k in keys_to_remove:
                    del current_nested[k]
                    
                if current_nested:  # 只保存有实际内容的嵌套结构
                    result[current_key] = dict(current_nested)
            
            pbar.close()  # 关闭进度条
        
        elapsed = time.time() - start_time
        print(f"  提取完成: {len(result)} 个嵌套对象, 耗时: {elapsed:.2f}秒")
        return result
    
    except Exception as e:
        print(f"  读取文件出错: {str(e)}")
        return {}

def compare_nested_values(original_csv, modified_csv, key_fields):
    """比较两个CSV文件的嵌套值结构，正确处理空值情况并避免无意义字段"""
    print(f"  开始比较嵌套值结构...")
    start_time = time.time()
    
    try:
        # 提取原版CSV的嵌套值
        orig_nested = extract_nested_values(original_csv, key_fields)
        
        # 提取更改版CSV的嵌套值
        mod_nested = extract_nested_values(modified_csv, key_fields)
        
        # 准备结果结构
        changes = {}
        
        # 检测修改和新对象
        new_count = 0
        mod_count = 0
        
        # 使用进度条处理修改版嵌套数据
        for key, mod_data in tqdm(mod_nested.items(), desc="检测嵌套修改", unit="对象"):
            # 新建对象处理
            if key not in orig_nested:
                # 过滤掉空值字段
                mod_data = {k: v for k, v in mod_data.items() if v}
                if mod_data:
                    changes[key] = mod_data
                    new_count += 1
            else:
                # 修改对象处理
                orig_data = orig_nested[key]
                changed_fields = {}
                
                # 检查所有字段
                for field, mod_values in mod_data.items():
                    # 新字段处理
                    if field not in orig_data:
                        # 只添加有实际内容的字段
                        if mod_values:
                            changed_fields[field] = mod_values
                            mod_count += 1
                    else:
                        # 修改字段处理
                        orig_values = orig_data[field]
                        
                        # 检查值是否相同
                        if mod_values != orig_values:
                            # 只添加有实际内容的修改
                            if mod_values:
                                changed_fields[field] = mod_values
                                mod_count += 1
                
                # 检查原版中有但修改版中没有的字段（设置为null）
                for field, orig_values in orig_data.items():
                    if field not in mod_data:
                        # 原版有值但修改版为空，设置为null
                        changed_fields[field] = None
                        mod_count += 1
                
                # 添加有实际修改的内容
                if changed_fields:
                    changes[key] = changed_fields
        
        elapsed = time.time() - start_time
        print(f"  比较完成: 发现 {len(changes)} 处修改 ({new_count} 项新建, {mod_count} 项修改), 耗时: {elapsed:.2f}秒")
        return changes
    
    except Exception as e:
        print(f"  比较文件出错: {str(e)}")
        return {}

def validate_numeric_fields(data, config):
    """验证数字字段，确保只包含数字值"""
    if not data:
        return
    
    # 从配置获取数字字段列表
    numeric_fields = set(config.get("numeric_fields", []))
    
    for section, content in data.items():
        if not isinstance(content, dict):
            continue
            
        for key, value in content.items():
            # 跳过无效的键和null值
            if key is None or value is None:
                continue
                
            # 检查字段名是否在数字字段列表中
            if key.lower() in numeric_fields:
                # 处理列表值
                if isinstance(value, list):
                    for i, item in enumerate(value):
                        # 跳过无效的值
                        if item is None:
                            continue
                            
                        if not isinstance(item, (int, float)) and not str(item).isdigit():
                            print(f"警告: 字段 '{key}' 应为数字，但值为 '{item}'，已设置为0")
                            value[i] = 0
                # 处理单个值
                elif value is not None and not isinstance(value, (int, float)) and not str(value).isdigit():
                    print(f"警告: 字段 '{key}' 应为数字，但值为 '{value}'，已设置为0")
                    content[key] = 0

def fix_problem_values(data, config):
    """根据配置修复问题值"""
    if not data:
        return
    
    # 从配置获取问题值设置
    problem_values = config.get("problem_values", {})
    
    for problem_value, settings in problem_values.items():
        target_fields = set(settings.get("fields", []))
        replace_with = settings.get("replace_with", 0)
        
        for section, content in data.items():
            if isinstance(content, dict):
                for key, value in content.items():
                    # 跳过null值
                    if value is None:
                        continue
                        
                    # 检查值是否包含问题值
                    if isinstance(value, str) and problem_value in value:
                        # 如果字段在目标字段中
                        if key.lower() in target_fields:
                            print(f"修复: 字段 '{key}' 的值 '{value}' 替换为 {replace_with}")
                            content[key] = replace_with
                    # 处理列表值
                    elif isinstance(value, list):
                        for i, item in enumerate(value):
                            if item is None:
                                continue
                                
                            if isinstance(item, str) and problem_value in item:
                                if key.lower() in target_fields:
                                    print(f"修复: 字段 '{key}' 的值 '{item}' 替换为 {replace_with}")
                                    value[i] = replace_with

def simplify_data_structure(data):
    """简化数据结构：将单元素列表转换为单个值，保留null值"""
    if isinstance(data, dict):
        for key, value in list(data.items()):  # 使用list避免字典改变大小问题
            if value is None:
                continue  # 保留null值
                
            if isinstance(value, list):
                # 过滤掉空列表
                if not value:
                    del data[key]
                    continue
                    
                # 单元素列表转换为单个值
                if len(value) == 1:
                    data[key] = value[0]
                else:
                    # 处理列表中的字典
                    for item in value:
                        if isinstance(item, dict):
                            simplify_data_structure(item)
            elif isinstance(value, dict):
                simplify_data_structure(value)  # 递归处理字典
    elif isinstance(data, list):
        for item in data:
            if isinstance(item, dict):
                simplify_data_structure(item)

def generate_combined_mod(csv_pairs, config):
    """
    生成合并的模组JSON文件 - 自动处理所有匹配的CSV文件对
    """
    mod_metadata = config.get("mod_metadata", {})
    key_fields = config.get("key_fields", ["Name", "TID"])  # 使用配置中的key_fields列表
    output_file = config.get("output_file", "content.json")
    
    total_start = time.time()
    print(f"\n开始生成模组: {mod_metadata.get('title', '综合修改模组')}")
    
    # 构建模组结构
    combined_mod = {
        "@title": mod_metadata.get("title", "综合修改模组"),
        "@description": mod_metadata.get("description", {"CN": "自动生成的综合修改模组"}),
        "@author": mod_metadata.get("author", "自动生成"),
        "@gv": mod_metadata.get("gv", 1)
    }
    
    # 处理所有CSV对
    processed_count = 0
    skipped_count = 0
    
    for original_csv, modified_csv, json_key in csv_pairs:
        # 检查文件是否存在
        if not os.path.exists(original_csv):
            print(f"\n跳过: 原版CSV文件不存在 - {original_csv}")
            skipped_count += 1
            continue
        if not os.path.exists(modified_csv):
            print(f"\n跳过: 更改版CSV文件不存在 - {modified_csv}")
            skipped_count += 1
            continue
            
        print(f"\n处理: {os.path.basename(original_csv)} -> {os.path.basename(modified_csv)}")
        print(f"关键字段: {key_fields}")
        
        pair_start = time.time()
        changes = compare_nested_values(original_csv, modified_csv, key_fields)
        pair_elapsed = time.time() - pair_start
        
        if changes:
            # 修复特定问题值
            fix_problem_values(changes, config)
            
            # 验证数字字段
            validate_numeric_fields(changes, config)
            
            # 简化数据结构 - 过滤掉空值和无意义字段
            simplify_data_structure(changes)
            
            # 过滤掉空的修改对象
            if changes:
                # 直接使用原始结构
                combined_mod[json_key] = changes
                print(f"  处理完成: 找到 {len(changes)} 处修改, 耗时: {pair_elapsed:.2f}秒")
                processed_count += 1
            else:
                print(f"  未发现有效修改, 耗时: {pair_elapsed:.2f}秒")
                processed_count += 1
        else:
            print(f"  未发现修改, 耗时: {pair_elapsed:.2f}秒")
            processed_count += 1
    
    # 写入JSON文件
    print(f"\n正在写入JSON文件: {output_file}")
    write_start = time.time()
    
    try:
        # 使用进度条显示写入进度
        with tqdm(total=1, desc="写入JSON文件") as pbar:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(combined_mod, f, ensure_ascii=False, indent=2)
            pbar.update(1)
        
        write_elapsed = time.time() - write_start
        
        total_elapsed = time.time() - total_start
        print(f"\n已生成模组文件: {output_file}")
        print(f"处理统计: {processed_count} 个文件对已处理, {skipped_count} 个文件对被跳过")
        print(f"JSON写入耗时: {write_elapsed:.2f}秒")
        print(f"总处理时间: {total_elapsed:.2f}秒")
        
        # 计算平均处理速度
        total_size = 0
        for csv_pair in csv_pairs:
            if os.path.exists(csv_pair[0]):
                total_size += os.path.getsize(csv_pair[0])
        
        if total_size > 0:
            print(f"平均处理速度: {total_size/(total_elapsed*1024*1024):.2f} MB/s")
        else:
            print("平均处理速度: 没有可处理的文件")
        
        return combined_mod
    
    except Exception as e:
        print(f"写入JSON文件出错: {str(e)}")
        return None

# 主函数
if __name__ == "__main__":
    # 加载配置
    config = load_config()
    if not config:
        exit(1)
    
    # 查找匹配的文件对
    csv_pairs = find_matching_files(config)
    if not csv_pairs:
        print("未找到匹配的CSV文件对")
        exit(1)
    
    print(f"找到 {len(csv_pairs)} 对CSV文件:")
    for i, (orig, mod, key) in enumerate(csv_pairs):
        print(f"  {i+1}. {os.path.basename(orig)} -> {os.path.basename(mod)} (JSON键: {key})")
    
    # 生成合并模组
    generate_combined_mod(csv_pairs, config)
