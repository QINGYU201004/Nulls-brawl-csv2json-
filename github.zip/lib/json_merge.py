import json
import os
from tqdm import tqdm
from pathlib import Path
import copy

def deep_compare(obj1, obj2, path=""):
    """
    深度比较两个JSON对象，返回差异内容（忽略主JSON独有的内容）
    """
    differences = {}
    
    if type(obj1) != type(obj2):
        # 只在副JSON有值时记录差异
        if obj2 is not None:
            differences[path] = (obj1, obj2) if path else (obj1, obj2)
        return differences
    
    if isinstance(obj1, dict):
        # 只检查副JSON中的键
        for key in obj2:
            new_path = f"{path}.{key}" if path else key
            if key not in obj1:
                # 副JSON有而主JSON没有的键
                differences[new_path] = (None, obj2[key])
            else:
                # 递归比较嵌套对象
                nested_diff = deep_compare(obj1[key], obj2[key], new_path)
                differences.update(nested_diff)
    
    elif isinstance(obj1, list):
        # 简单列表比较 - 只比较相同索引位置的元素
        max_len = max(len(obj1), len(obj2))
        for i in range(max_len):
            new_path = f"{path}[{i}]"
            if i >= len(obj1):
                # 副JSON有额外元素
                differences[new_path] = (None, obj2[i])
            elif i >= len(obj2):
                # 副JSON没有这个元素（跳过）
                pass
            else:
                # 递归比较元素
                nested_diff = deep_compare(obj1[i], obj2[i], new_path)
                differences.update(nested_diff)
    
    else:
        # 基本类型比较
        if obj1 != obj2 and obj2 is not None:
            differences[path] = (obj1, obj2) if path else (obj1, obj2)
    
    return differences

def merge_json_files(main_json, secondary_json, output_path=None):
    """
    合并两个JSON文件，将副JSON的差异内容合并到主JSON
    保留主JSON独有的内容
    """
    print(f"\n开始合并JSON文件: {os.path.basename(main_json)} 和 {os.path.basename(secondary_json)}")
    
    try:
        # 读取主JSON文件
        with open(main_json, 'r', encoding='utf-8') as f:
            main_data = json.load(f)
        
        # 读取副JSON文件
        with open(secondary_json, 'r', encoding='utf-8') as f:
            secondary_data = json.load(f)
        
        # 深度比较两个JSON对象（忽略主JSON独有的内容）
        differences = deep_compare(main_data, secondary_data)
        
        if not differences:
            print("两个JSON文件内容完全相同，无需合并")
            return False
        
        print(f"发现 {len(differences)} 处差异:")
        for path, (main_val, sec_val) in differences.items():
            if main_val is None:
                print(f"  + {path}: {sec_val} (新增)")
            else:
                print(f"  ~ {path}: {main_val} -> {sec_val} (修改)")
        
        # 应用差异到主数据（保留主JSON独有的内容）
        merged_data = copy.deepcopy(main_data)
        apply_differences(merged_data, differences)
        
        # 确定输出路径
        if output_path is None:
            output_dir = os.path.join(os.path.dirname(main_json), "JSON_MERGED")
            os.makedirs(output_dir, exist_ok=True)
            file_name = f"merged_{os.path.basename(main_json)}"
            output_path = os.path.join(output_dir, file_name)
        
        # 写入合并后的JSON文件
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(merged_data, f, ensure_ascii=False, indent=2)
        
        print(f"已生成合并后的文件: {output_path}")
        return True
        
    except Exception as e:
        print(f"合并JSON文件出错: {str(e)}")
        return False

def apply_differences(merged_data, differences):
    """
    应用差异到主数据，保留主JSON独有的内容
    """
    for path, (main_val, sec_val) in differences.items():
        # 只处理副JSON中有值的情况（新增或修改）
        if sec_val is not None:
            # 解析路径
            path_parts = parse_path(path)
            
            # 导航到路径的父级
            current = merged_data
            for i, part in enumerate(path_parts[:-1]):
                # 处理索引（如 [0]）
                if part.startswith('[') and part.endswith(']'):
                    index = int(part[1:-1])
                    if index >= len(current):
                        # 扩展列表
                        current.extend([None] * (index - len(current) + 1))
                    current = current[index]
                else:
                    # 处理字典键
                    if part not in current:
                        # 创建新字典或列表（根据下一部分判断）
                        next_part = path_parts[i+1]
                        if next_part.startswith('[') and next_part.endswith(']'):
                            current[part] = []
                        else:
                            current[part] = {}
                    current = current[part]
            
            # 设置最终值
            last_part = path_parts[-1]
            if last_part.startswith('[') and last_part.endswith(']'):
                index = int(last_part[1:-1])
                if isinstance(current, list):
                    if index >= len(current):
                        # 扩展列表
                        current.extend([None] * (index - len(current) + 1))
                    current[index] = sec_val
            else:
                if isinstance(current, dict):
                    current[last_part] = sec_val

def parse_path(path):
    """
    解析路径字符串为部分列表
    """
    parts = []
    current = ""
    in_index = False
    
    for char in path:
        if char == '.' and not in_index:
            if current:
                parts.append(current)
                current = ""
        elif char == '[':
            if current:
                parts.append(current)
                current = ""
            in_index = True
            current += char
        elif char == ']':
            current += char
            parts.append(current)
            current = ""
            in_index = False
        else:
            current += char
    
    if current:
        parts.append(current)
    
    return parts

def json_merge_ui():
    """
    JSON合并功能的用户界面
    """
    print("\n" + "="*50)
    print("JSON文件合并工具（保留主JSON独有内容）")
    print("="*50)
    
    # 获取目录路径
    data_folder = input("请输入JSON文件所在目录 (默认为当前目录): ").strip() or "."
    
    if not os.path.exists(data_folder):
        print(f"目录不存在: {data_folder}")
        return False
    
    # 获取目录中的JSON文件
    json_files = [f for f in os.listdir(data_folder) if f.endswith('.json')]
    if not json_files:
        print(f"目录 {data_folder} 中没有JSON文件")
        return False
    
    # 显示文件列表
    print("\n可用的JSON文件:")
    for i, f in enumerate(json_files, 1):
        print(f"{i}: {f}")
    
    # 选择主JSON文件
    try:
        main_idx = int(input("\n请选择主JSON文件编号: ")) - 1
        if main_idx < 0 or main_idx >= len(json_files):
            raise ValueError
    except ValueError:
        print("无效的选择")
        return False
    
    # 选择副JSON文件
    try:
        sec_idx = int(input("请选择副JSON文件编号: ")) - 1
        if sec_idx < 0 or sec_idx >= len(json_files):
            raise ValueError
    except ValueError:
        print("无效的选择")
        return False
    
    # 获取完整路径
    main_json = os.path.join(data_folder, json_files[main_idx])
    secondary_json = os.path.join(data_folder, json_files[sec_idx])
    
    # 执行合并
    return merge_json_files(main_json, secondary_json)
