import csv
import os
from tqdm import tqdm

def detect_csv_structure(csv_file):
    """
    检测CSV文件的结构，判断是否有类型行
    返回: (has_type_row, header, type_row)
    """
    with open(csv_file, 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader)
        
        # 尝试读取下一行，判断是否为类型行
        try:
            type_row = next(reader)
            # 简单启发式判断：如果类型行包含常见类型关键字，则认为有类型行
            type_keywords = ['string', 'int', 'float', 'number', 'date', 'datetime', 'boolean']
            has_type_keywords = any(keyword in cell.lower() for cell in type_row 
                                   for keyword in type_keywords if cell)
            
            # 或者如果类型行不包含明显的数据值（如数字、日期格式等）
            # 这里简化处理，假设有类型行
            has_type_row = has_type_keywords or len(type_row) == len(header)
            
            if has_type_row:
                return True, header, type_row
            else:
                # 如果不是类型行，则回退
                return False, header, None
        except StopIteration:
            # 文件只有一行
            return False, header, None

def compare_csv_headers(original_csv, modified_csv):
    """
    比较两个CSV文件的表头差异
    删除修改版CSV中多余的列，包括所有无名称的列
    """
    print(f"\n开始比较表头差异: {os.path.basename(original_csv)} vs {os.path.basename(modified_csv)}")
    
    try:
        # 检测原版CSV结构
        orig_has_type, orig_header, orig_type_row = detect_csv_structure(original_csv)
        orig_header_set = set(orig_header)
        
        # 检测修改版CSV结构
        mod_has_type, mod_header, mod_type_row = detect_csv_structure(modified_csv)
        mod_header_set = set(mod_header)
        
        # 找出修改版中多余的列
        extra_columns = mod_header_set - orig_header_set
        
        # 找出所有无名称的列（空白列）
        blank_columns = set()
        for i, col in enumerate(mod_header):
            if col.strip() == "":  # 检测空白列名
                blank_columns.add(col)
                print(f"发现空白列（索引 {i}），将自动删除")
        
        # 合并需要删除的列
        extra_columns = extra_columns | blank_columns
        
        if not extra_columns:
            print("没有发现多余的列")
            return False
        
        print(f"发现 {len(extra_columns)} 个多余列:")
        for col in extra_columns:
            col_display = f"空白列" if col == "" else col
            print(f"  - {col_display}")
        
        # 确定要保留的列索引
        keep_indices = [i for i, col in enumerate(mod_header) if col not in extra_columns]
        
        # 创建输出目录
        output_dir = os.path.join(os.path.dirname(modified_csv), "CSV", "CSV_CLEAN")
        os.makedirs(output_dir, exist_ok=True)
        
        # 创建输出文件名
        file_name = os.path.basename(modified_csv)
        output_csv = os.path.join(output_dir, file_name)
        
        # 处理整个文件
        total_lines = 0
        with open(modified_csv, 'r', encoding='utf-8') as f_in:
            total_lines = sum(1 for _ in f_in)
            f_in.seek(0)
        
        with open(modified_csv, 'r', encoding='utf-8') as f_in, \
             open(output_csv, 'w', encoding='utf-8', newline='') as f_out:
            
            # 创建CSV读写器
            reader = csv.reader(f_in)
            writer = csv.writer(f_out)
            
            # 使用进度条
            pbar = tqdm(total=total_lines, desc="处理文件", unit="行")
            
            # 处理表头行
            header_row = next(reader)
            cleaned_header = [header_row[i] for i in keep_indices]
            writer.writerow(cleaned_header)
            pbar.update(1)
            
            # 处理类型行（如果有）
            if mod_has_type:
                type_row = next(reader)
                cleaned_type_row = [type_row[i] for i in keep_indices]
                writer.writerow(cleaned_type_row)
                pbar.update(1)
            
            # 处理剩余的数据行
            for row in reader:
                cleaned_row = [row[i] for i in keep_indices]
                writer.writerow(cleaned_row)
                pbar.update(1)
            
            pbar.close()
        
        print(f"已生成清理后的文件: {output_csv}")
        return True
    
    except Exception as e:
        print(f"比较表头出错: {str(e)}")
        return False

def add_missing_columns(original_csv, modified_csv):
    """
    比较两个CSV文件的表头差异
    在修改版CSV中增加原版CSV有而修改版CSV没有的列，并保持原版列顺序
    """
    print(f"\n开始比较表头差异并添加缺失列: {os.path.basename(original_csv)} vs {os.path.basename(modified_csv)}")
    
    try:
        # 检测原版CSV结构
        orig_has_type, orig_header, orig_type_row = detect_csv_structure(original_csv)
        
        # 检测修改版CSV结构
        mod_has_type, mod_header, mod_type_row = detect_csv_structure(modified_csv)
        
        # 创建列名到索引的映射
        orig_col_index_map = {col: i for i, col in enumerate(orig_header)}
        mod_col_index_map = {col: i for i, col in enumerate(mod_header)}
        
        # 找出原版中有但修改版中没有的列
        missing_columns = [col for col in orig_header if col not in mod_col_index_map and col.strip() != ""]
        
        if not missing_columns:
            print("没有发现缺失的列")
            return False
        
        print(f"发现 {len(missing_columns)} 个缺失列:")
        for col in missing_columns:
            print(f"  - {col}")
        
        # 创建输出目录
        output_dir = os.path.join(os.path.dirname(modified_csv), "CSV", "CSV_ADDED")
        os.makedirs(output_dir, exist_ok=True)
        
        # 创建输出文件名
        file_name = os.path.basename(modified_csv)
        output_csv = os.path.join(output_dir, file_name)
        
        # 处理整个文件
        total_lines = 0
        with open(modified_csv, 'r', encoding='utf-8') as f_in:
            total_lines = sum(1 for _ in f_in)
            f_in.seek(0)
        
        with open(modified_csv, 'r', encoding='utf-8') as f_in, \
             open(output_csv, 'w', encoding='utf-8', newline='') as f_out:
            
            # 创建CSV读写器
            reader = csv.reader(f_in)
            writer = csv.writer(f_out)
            
            # 使用进度条
            pbar = tqdm(total=total_lines, desc="处理文件", unit="行")
            
            # 处理表头行 - 按照原版顺序重建表头
            header_row = next(reader)
            
            # 创建新的表头，按照原版顺序
            new_header = []
            for col in orig_header:
                if col in mod_col_index_map:  # 修改版中已有的列
                    new_header.append(col)
                elif col in missing_columns:  # 缺失的列
                    new_header.append(col)
            
            writer.writerow(new_header)
            pbar.update(1)
            
            # 处理类型行（如果有）
            if mod_has_type:
                type_row = next(reader)
                
                # 创建新的类型行，按照原版顺序
                new_type_row = []
                for col in orig_header:
                    if col in mod_col_index_map:  # 修改版中已有的列
                        new_type_row.append(type_row[mod_col_index_map[col]])
                    elif col in missing_columns:  # 缺失的列
                        # 从原版获取类型信息
                        col_idx = orig_col_index_map[col]
                        type_value = orig_type_row[col_idx] if orig_has_type else ""
                        new_type_row.append(type_value)
                
                writer.writerow(new_type_row)
                pbar.update(1)
            
            # 处理数据行
            for row in reader:
                # 创建新的数据行，按照原版顺序
                new_row = []
                for col in orig_header:
                    if col in mod_col_index_map:  # 修改版中已有的列
                        new_row.append(row[mod_col_index_map[col]])
                    elif col in missing_columns:  # 缺失的列
                        new_row.append("")  # 添加空值
                
                writer.writerow(new_row)
                pbar.update(1)
            
            pbar.close()
        
        print(f"已生成添加缺失列后的文件: {output_csv}")
        return True
    
    except Exception as e:
        print(f"添加缺失列出错: {str(e)}")
        return False
